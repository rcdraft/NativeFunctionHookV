﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NativeFunctionHookV.Network
{
    /// <summary>
    /// Controls network game environment.
    /// Make sure you use it in controlled environment instead of GTA Online, otherwise you will be banned.
    /// </summary>
    public static class NetworkGame
    {

    }
}
