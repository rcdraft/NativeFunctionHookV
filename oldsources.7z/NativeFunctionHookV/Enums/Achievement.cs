﻿namespace NativeFunctionHookV
{
    public enum Achievement
    {
        WelcomeToLosSantos = 43,
        AFriendshipResurrected = 40
    }
}