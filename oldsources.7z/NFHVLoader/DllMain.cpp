/**
 * Copyright (C) 2015 crosire & contributors
 * License: https://github.com/crosire/scripthookvdotnet#license
 */

/**
 * Copyright (C) 2020 RelaperCrystal
*/

bool sGameReloaded = false;

#pragma managed

using namespace System;
using namespace System::Reflection;
namespace WinForms = System::Windows::Forms;

[assembly:AssemblyTitle("NFH V Loader")];
[assembly:AssemblyDescription("An ASI plugin for Grand Theft Auto V, which allows running scripts written in any .NET language in-game.")] ;
[assembly:AssemblyCompany("RelaperCrystal")] ;
[assembly:AssemblyProduct("NativeFunctionHookV")] ;
[assembly:AssemblyCopyright("Copyright (C) 2015 crosire, (C) 2020 RelaperCrystal")] ;
[assembly:AssemblyVersion("0.0.0.0")] ;
[assembly:AssemblyFileVersion("0.0.0.0")] ;

public ref class NativeFunctionHookV
{

};